<?php


namespace Alan\CustomCustomerRegistration\Model\Logger;


class Logger extends \Monolog\Logger
{

}
